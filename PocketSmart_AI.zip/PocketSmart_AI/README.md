# PocketSmart AI

PocketSmart AI is an AI-powered Smart Budget & Recommendation Assistant.

It helps users plan budgets for:

- Home Interior
- Parties and Events
- Jewelry

The application uses a React frontend and FastAPI backend.

## Features

- User Registration
- User Login
- JWT Authentication
- Home Budget Planner
- Party Budget Planner
- Jewelry Budget Planner
- Outfit Image Upload
- Gemini AI Integration
- Local AI Fallback
- INR Budget Calculation
- Shopping Search Links
- Recommendation History
- SQLite Database
- Swagger API Documentation

## Technologies

Frontend:
- React
- Vite
- JavaScript
- CSS
- Lucide React

Backend:
- Python
- FastAPI
- SQLAlchemy
- SQLite
- JWT
- Google Gemini API

## Run Backend

```powershell
cd backend

python -m venv venv

.\venv\Scripts\Activate.ps1

pip install -r requirements.txt

copy .env.example .env

uvicorn app.main:app --reload
