import React, {
  useEffect,
  useState
} from "react";

import {
  ArrowRight,
  CheckCircle2,
  Clock3,
  Gem,
  Home,
  LogIn,
  LogOut,
  PartyPopper,
  Sparkles,
  Upload,
  WalletCards,
  X
} from "lucide-react";


const API =
  import.meta.env.VITE_API_URL ||
  "http://127.0.0.1:8000";


async function api(
  path,
  options = {}
) {

  const token =
    localStorage.getItem(
      "pocketsmart_token"
    );


  const headers =
    new Headers(
      options.headers || {}
    );


  if (token) {

    headers.set(
      "Authorization",
      `Bearer ${token}`
    );

  }


  if (
    options.body &&
    !(options.body instanceof FormData) &&
    !headers.has("Content-Type")
  ) {

    headers.set(
      "Content-Type",
      "application/json"
    );

  }


  const response =
    await fetch(
      `${API}${path}`,
      {
        ...options,
        headers
      }
    );


  const data =
    await response
      .json()
      .catch(
        () => ({})
      );


  if (!response.ok) {

    throw new Error(
      data.detail ||
      "Something went wrong"
    );

  }


  return data;
}


function money(value) {

  return `₹${Number(
    value || 0
  ).toLocaleString(
    "en-IN",
    {
      maximumFractionDigits: 2
    }
  )}`;
}


export default function App() {

  const [
    user,
    setUser
  ] = useState(null);


  const [
    page,
    setPage
  ] = useState("home");


  const [
    authMode,
    setAuthMode
  ] = useState("login");


  const [
    result,
    setResult
  ] = useState(null);


  const [
    busy,
    setBusy
  ] = useState(false);


  const [
    message,
    setMessage
  ] = useState("");


  useEffect(() => {

    const token =
      localStorage.getItem(
        "pocketsmart_token"
      );


    if (!token) return;


    api("/auth/me")

      .then(setUser)

      .catch(() => {

        localStorage.removeItem(
          "pocketsmart_token"
        );

      });

  }, []);


  function logout() {

    localStorage.removeItem(
      "pocketsmart_token"
    );

    setUser(null);

    setPage("home");

    setResult(null);
  }


  if (!user) {

    return (

      <AuthScreen

        mode={authMode}

        setMode={setAuthMode}

        onLogin={setUser}

      />

    );

  }


  return (

    <div className="app-shell">

      <header className="topbar">

        <button
          className="brand"
          onClick={() => {
            setPage("home");
            setResult(null);
          }}
        >

          <span className="brand-mark">

            <Sparkles size={18} />

          </span>

          PocketSmart

        </button>


        <nav>

          <button
            onClick={() => {
              setPage("home");
              setResult(null);
            }}
          >
            Home
          </button>


          <button
            onClick={() => {
              setPage("history");
              setResult(null);
            }}
          >
            History
          </button>


          <span className="user-pill">
            {user.username}
          </span>


          <button
            className="logout"
            onClick={logout}
          >

            <LogOut size={16} />

            Logout

          </button>

        </nav>

      </header>


      <main className="page">

        {page === "home" && (

          <Dashboard
            onOpen={(value) => {
              setPage(value);
              setResult(null);
            }}
          />

        )}


        {page === "history" && (
          <History />
        )}


        {page === "home-planner" && (

          <Planner
            type="home"
            result={result}
            setResult={setResult}
            busy={busy}
            setBusy={setBusy}
            message={message}
            setMessage={setMessage}
          />

        )}


        {page === "party-planner" && (

          <Planner
            type="party"
            result={result}
            setResult={setResult}
            busy={busy}
            setBusy={setBusy}
            message={message}
            setMessage={setMessage}
          />

        )}


        {page === "jewelry-planner" && (

          <Planner
            type="jewelry"
            result={result}
            setResult={setResult}
            busy={busy}
            setBusy={setBusy}
            message={message}
            setMessage={setMessage}
          />

        )}

      </main>

    </div>

  );
}


function AuthScreen({
  mode,
  setMode,
  onLogin
}) {

  const [
    form,
    setForm
  ] = useState({

    username: "",
    email: "",
    password: ""

  });


  const [
    error,
    setError
  ] = useState("");


  async function submit(event) {

    event.preventDefault();

    setError("");


    try {

      if (mode === "register") {

        await api(
          "/auth/register",
          {
            method: "POST",

            body: JSON.stringify(
              form
            )
          }
        );

      }


      const data =
        await api(
          "/auth/login",
          {
            method: "POST",

            body: JSON.stringify({
              username:
                form.username,

              password:
                form.password
            })
          }
        );


      localStorage.setItem(
        "pocketsmart_token",
        data.access_token
      );


      const currentUser =
        await api(
          "/auth/me"
        );


      onLogin(
        currentUser
      );

    } catch (error) {

      setError(
        error.message
      );

    }

  }


  return (

    <div className="auth-page">

      <div className="auth-card">

        <div className="brand centered">

          <span className="brand-mark">

            <Sparkles size={18} />

          </span>

          PocketSmart

        </div>


        <h1>

          {mode === "login"
            ? "Welcome back"
            : "Create your account"}

        </h1>


        <p className="muted">

          AI-powered budget planning
          for everyday needs.

        </p>


        <form onSubmit={submit}>

          <label>

            Username

            <input

              required

              value={
                form.username
              }

              onChange={(event) =>
                setForm({
                  ...form,
                  username:
                    event.target.value
                })
              }

            />

          </label>


          {mode === "register" && (

            <label>

              Email

              <input

                required

                type="email"

                value={
                  form.email
                }

                onChange={(event) =>
                  setForm({
                    ...form,
                    email:
                      event.target.value
                  })
                }

              />

            </label>

          )}


          <label>

            Password

            <input

              required

              minLength="6"

              type="password"

              value={
                form.password
              }

              onChange={(event) =>
                setForm({
                  ...form,
                  password:
                    event.target.value
                })
              }

            />

          </label>


          {error && (

            <div className="error">

              {error}

            </div>

          )}


          <button
            className="primary wide"
            type="submit"
          >

            {mode === "login" ? (

              <>
                <LogIn size={17} />
                Sign in
              </>

            ) : (

              "Create account"

            )}

          </button>

        </form>


        <button

          className="link-button"

          onClick={() =>
            setMode(
              mode === "login"
                ? "register"
                : "login"
            )
          }

        >

          {mode === "login"
            ? "Don't have an account? Create one"
            : "Already have an account? Sign in"}

        </button>

      </div>

    </div>

  );
}


function Dashboard({
  onOpen
}) {

  const cards = [

    {
      key:
        "home-planner",

      title:
        "Home Interior",

      text:
        "Plan furniture, lighting and decor without overspending.",

      icon:
        <Home />
    },

    {
      key:
        "party-planner",

      title:
        "Party Planner",

      text:
        "Allocate venue, food, decoration and entertainment costs.",

      icon:
        <PartyPopper />
    },

    {
      key:
        "jewelry-planner",

      title:
        "Jewelry Planner",

      text:
        "Find jewelry ideas that fit your occasion and budget.",

      icon:
        <Gem />
    }

  ];


  return (

    <>

      <section className="hero">

        <div>

          <span className="eyebrow">

            <Sparkles size={14} />

            AI-Powered Budget Planning

          </span>


          <h1>

            Make smarter decisions
            <br />

            with PocketSmart AI.

          </h1>


          <p>

            Build practical INR budgets
            and get personalized
            recommendations for your
            home, events and jewelry.

          </p>

        </div>


        <div className="hero-card">

          <WalletCards size={32} />

          <strong>
            Budget first.
          </strong>

          <span>
            Recommendations stay
            within your target budget.
          </span>

        </div>

      </section>


      <section className="section-head">

        <div>

          <h2>
            Smart Budget Planners
          </h2>

          <p className="muted">
            Choose an area to start planning.
          </p>

        </div>

      </section>


      <div className="card-grid">

        {cards.map((card) => (

          <button

            key={card.key}

            className="planner-card"

            onClick={() =>
              onOpen(card.key)
            }

          >

            <div className="icon-box">

              {card.icon}

            </div>


            <h3>
              {card.title}
            </h3>


            <p>
              {card.text}
            </p>


            <span>

              Open planner

              <ArrowRight
                size={16}
              />

            </span>

          </button>

        ))}

      </div>

    </>

  );
}


function Planner({
  type,
  result,
  setResult,
  busy,
  setBusy,
  message,
  setMessage
}) {

  const [
    form,
    setForm
  ] = useState(

    type === "home"

      ? {
          total_budget: "",
          room_type:
            "Living room",
          style:
            "Modern",
          priorities: "",
          additional_requirements:
            ""
        }

      : type === "party"

      ? {
          total_budget: "",
          party_type:
            "Birthday",
          num_guests:
            "10",
          venue_type: "",
          event_date: "",
          needs: "",
          additional_requirements:
            ""
        }

      : {
          total_budget: "",
          occasion:
            "Wedding",
          preferences: "",
          image: null
        }

  );


  const title =

    type === "home"

      ? "Home Interior Budget Planner"

      : type === "party"

      ? "Party Budget Planner"

      : "Jewelry Budget Planner";


  async function submit(event) {

    event.preventDefault();

    setBusy(true);

    setMessage("");

    setResult(null);


    try {

      let data;


      if (type === "jewelry") {

        const formData =
          new FormData();


        formData.append(
          "total_budget",
          form.total_budget
        );


        formData.append(
          "occasion",
          form.occasion
        );


        formData.append(
          "preferences",
          form.preferences || ""
        );


        if (form.image) {

          formData.append(
            "image",
            form.image
          );

        }


        data =
          await api(
            "/api/jewelry-budget",
            {
              method: "POST",
              body: formData
            }
          );

      } else {

        data =
          await api(
            `/api/${type}-budget`,
            {
              method: "POST",

              body:
                JSON.stringify({

                  ...form,

                  total_budget:
                    Number(
                      form.total_budget
                    ),

                  ...(type === "party"
                    ? {
                        num_guests:
                          Number(
                            form.num_guests
                          )
                      }
                    : {})

                })
            }
          );

      }


      setResult(data);

    } catch (error) {

      setMessage(
        error.message
      );

    } finally {

      setBusy(false);

    }

  }


  return (

    <div>

      <div className="page-title">

        <div>

          <span className="eyebrow">

            <Sparkles size={14} />

            PocketSmart

          </span>


          <h1>
            {title}
          </h1>


          <p className="muted">

            Generate an AI-powered
            plan in INR.

          </p>

        </div>

      </div>


      <div className="planner-layout">

        <form
          className="form-card"
          onSubmit={submit}
        >

          <label>

            Total Budget (₹)

            <input

              required

              type="number"

              min="1"

              value={
                form.total_budget
              }

              onChange={(event) =>
                setForm({
                  ...form,
                  total_budget:
                    event.target.value
                })
              }

              placeholder="e.g. 50000"

            />

          </label>


          {type === "home" && (

            <>

              <label>

                Room Type

                <input

                  required

                  value={
                    form.room_type
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      room_type:
                        event.target.value
                    })
                  }

                />

              </label>


              <label>

                Style

                <input

                  value={
                    form.style
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      style:
                        event.target.value
                    })
                  }

                />

              </label>


              <label>

                Priorities

                <textarea

                  value={
                    form.priorities
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      priorities:
                        event.target.value
                    })
                  }

                  placeholder=
                    "Storage, lighting, seating..."

                />

              </label>


              <label>

                Additional Requirements

                <textarea

                  value={
                    form.additional_requirements
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      additional_requirements:
                        event.target.value
                    })
                  }

                />

              </label>

            </>

          )}


          {type === "party" && (

            <>

              <label>

                Party Type

                <input

                  required

                  value={
                    form.party_type
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      party_type:
                        event.target.value
                    })
                  }

                />

              </label>


              <label>

                Number of Guests

                <input

                  required

                  type="number"

                  min="1"

                  value={
                    form.num_guests
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      num_guests:
                        event.target.value
                    })
                  }

                />

              </label>


              <label>

                Venue Type

                <input

                  value={
                    form.venue_type
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      venue_type:
                        event.target.value
                    })
                  }

                  placeholder=
                    "Hall, home, outdoor..."

                />

              </label>


              <label>

                Event Date

                <input

                  type="date"

                  value={
                    form.event_date
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      event_date:
                        event.target.value
                    })
                  }

                />

              </label>


              <label>

                Party Needs

                <textarea

                  value={
                    form.needs
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      needs:
                        event.target.value
                    })
                  }

                  placeholder=
                    "Food, decoration, music..."

                />

              </label>

            </>

          )}


          {type === "jewelry" && (

            <>

              <label>

                Occasion

                <input

                  required

                  value={
                    form.occasion
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      occasion:
                        event.target.value
                    })
                  }

                />

              </label>


              <label>

                Preferences

                <textarea

                  value={
                    form.preferences
                  }

                  onChange={(event) =>
                    setForm({
                      ...form,
                      preferences:
                        event.target.value
                    })
                  }

                  placeholder=
                    "Gold tone, minimal, traditional..."

                />

              </label>


              <label>

                Outfit Image

                <input

                  type="file"

                  accept=
                    "image/png,image/jpeg,image/webp"

                  onChange={(event) =>
                    setForm({
                      ...form,
                      image:
                        event.target.files?.[0]
                        || null
                    })
                  }

                />

              </label>


              {form.image && (

                <div className="file-chip">

                  <Upload size={15} />

                  {form.image.name}

                  <button

                    type="button"

                    onClick={() =>
                      setForm({
                        ...form,
                        image: null
                      })
                    }

                  >

                    <X size={14} />

                  </button>

                </div>

              )}

            </>

          )}


          {message && (

            <div className="error">

              {message}

            </div>

          )}


          <button

            className="primary wide"

            disabled={busy}

          >

            {busy

              ? "Generating..."

              : (
                <>
                  <Sparkles size={17} />
                  Generate Recommendations
                </>
              )}

          </button>

        </form>


        <div className="result-area">

          {!result ? (

            <div className="empty-state">

              <Sparkles size={34} />

              <h3>

                Your personalized
                plan will appear here

              </h3>

              <p>

                Enter your budget
                and preferences,
                then generate
                recommendations.

              </p>

            </div>

          ) : (

            <RecommendationResult
              result={result}
            />

          )}

        </div>

      </div>

    </div>

  );
}


function RecommendationResult({
  result
}) {

  return (

    <div className="result-stack">

      <div className="result-summary">

        <div>

          <span className="eyebrow">

            Budget Summary

          </span>


          <h2>

            {money(
              result.total_budget
            )}

          </h2>


          <p>

            Remaining budget:

            {" "}

            <strong>

              {money(
                result.remaining_budget
              )}

            </strong>

          </p>

        </div>


        <span className="source-badge">

          <CheckCircle2 size={15} />

          {result.source ===
          "local_fallback"
            ? "Local fallback"
            : "Gemini AI"}

        </span>

      </div>


      {result.outfit_analysis && (

        <div className="result-card">

          <h3>
            Outfit Analysis
          </h3>

          <p>

            <strong>
              Colors:
            </strong>

            {" "}

            {(
              result.outfit_analysis.colors
              || []
            ).join(", ")
              || "Not specified"}

          </p>


          <p>

            <strong>
              Style:
            </strong>

            {" "}

            {
              result.outfit_analysis.style
            }

          </p>


          <p>

            <strong>
              Formality:
            </strong>

            {" "}

            {
              result.outfit_analysis.formality
            }

          </p>

        </div>

      )}


      {(result.budget_breakdown || [])
        .map((category, index) => (

          <div
            className="result-card"
            key={index}
          >

            <div className="card-heading">

              <div>

                <h3>
                  {category.category}
                </h3>

                <span className="muted">

                  Allocation:

                  {" "}

                  {money(
                    category.allocation
                  )}

                </span>

              </div>

            </div>


            {(category.items || [])
              .map((item, itemIndex) => (

                <div
                  className="item-row"
                  key={itemIndex}
                >

                  <div>

                    <strong>
                      {item.name}
                    </strong>

                    <p>
                      {item.description}
                    </p>

                    <span>
                      Qty:
                      {" "}
                      {item.quantity || 1}
                    </span>

                  </div>


                  <div className="item-right">

                    <strong>

                      {money(
                        item.estimated_price
                      )}

                    </strong>


                    <div className="links">

                      {Object.entries(
                        item.shopping_links || {}
                      )
                        .slice(0, 4)
                        .map(
                          ([name, url]) => (

                            <a
                              key={name}
                              href={url}
                              target="_blank"
                              rel="noreferrer"
                            >

                              {name}

                            </a>

                          )
                        )}

                    </div>

                  </div>

                </div>

              ))}

          </div>

        ))}


      {result.jewelry_recommendations?.length > 0 && (

        <div className="result-card">

          <h3>
            Jewelry Recommendations
          </h3>


          {result.jewelry_recommendations
            .map((item, index) => (

              <div
                className="item-row"
                key={index}
              >

                <div>

                  <strong>
                    {item.item_type}
                  </strong>

                  <p>
                    {item.description}
                  </p>

                  <span>
                    {item.style}
                  </span>

                </div>


                <div className="item-right">

                  <strong>

                    {money(
                      item.estimated_price
                    )}

                  </strong>


                  <div className="links">

                    {Object.entries(
                      item.shopping_links || {}
                    )
                      .slice(0, 4)
                      .map(
                        ([name, url]) => (

                          <a
                            key={name}
                            href={url}
                            target="_blank"
                            rel="noreferrer"
                          >

                            {name}

                          </a>

                        )
                      )}

                  </div>

                </div>

              </div>

            ))}

        </div>

      )}


      {result.additional_suggestions?.length > 0 && (

        <div className="result-card">

          <h3>
            Additional Suggestions
          </h3>


          <ul className="suggestions">

            {result.additional_suggestions
              .map((item, index) => (

                <li key={index}>
                  {item}
                </li>

              ))}

          </ul>

        </div>

      )}

    </div>

  );
}


function History() {

  const [
    items,
    setItems
  ] = useState([]);


  const [
    error,
    setError
  ] = useState("");


  useEffect(() => {

    api("/api/history")

      .then(setItems)

      .catch((error) =>
        setError(
          error.message
        )
      );

  }, []);


  return (

    <div>

      <div className="page-title">

        <div>

          <span className="eyebrow">

            <Clock3 size={14} />

            Saved Plans

          </span>


          <h1>
            Recommendation History
          </h1>


          <p className="muted">

            Your previous PocketSmart
            recommendations.

          </p>

        </div>

      </div>


      {error && (

        <div className="error">
          {error}
        </div>

      )}


      {!items.length &&
      !error ? (

        <div className="empty-state">

          <Clock3 size={34} />

          <h3>
            No recommendations yet
          </h3>

          <p>

            Generate a plan and
            it will appear here.

          </p>

        </div>

      ) : (

        <div className="history-list">

          {items.map((item) => (

            <div
              className="history-card"
              key={item.id}
            >

              <div>

                <span className="type-tag">

                  {item.type}

                </span>


                <h3>

                  {money(
                    item.total_budget
                  )}

                </h3>


                <p>

                  {new Date(
                    item.timestamp
                  ).toLocaleString()}

                </p>

              </div>


              <div className="history-detail">

                <strong>

                  {item.summary
                    ?.additional_suggestions
                    ?.[
                      0
                    ]
                    ||
                    "Budget plan saved"}

                </strong>


                <span>

                  Plan generated and
                  stored for your account.

                </span>

              </div>

            </div>

          ))}

        </div>

      )}

    </div>

  );
}