from __future__ import annotations

from typing import Optional

from pydantic import (
    BaseModel,
    EmailStr,
    Field,
    field_validator
)


class RegisterRequest(BaseModel):

    username: str = Field(
        min_length=3,
        max_length=80
    )

    email: EmailStr

    password: str = Field(
        min_length=6,
        max_length=128
    )

    @field_validator("username")
    @classmethod
    def clean_username(cls, value: str) -> str:

        value = value.strip()

        if not value:
            raise ValueError(
                "Username is required"
            )

        return value


class LoginRequest(BaseModel):

    username: str

    password: str


class HomeBudgetInput(BaseModel):

    total_budget: float = Field(
        gt=0
    )

    room_type: str = Field(
        min_length=2,
        max_length=80
    )

    style: Optional[str] = Field(
        default=None,
        max_length=200
    )

    priorities: Optional[str] = Field(
        default=None,
        max_length=500
    )

    additional_requirements: Optional[str] = Field(
        default=None,
        max_length=1000
    )


class PartyBudgetInput(BaseModel):

    total_budget: float = Field(
        gt=0
    )

    party_type: str = Field(
        min_length=2,
        max_length=100
    )

    num_guests: int = Field(
        gt=0,
        le=5000
    )

    venue_type: Optional[str] = Field(
        default=None,
        max_length=100
    )

    event_date: Optional[str] = Field(
        default=None,
        max_length=30
    )

    needs: Optional[str] = Field(
        default=None,
        max_length=500
    )

    additional_requirements: Optional[str] = Field(
        default=None,
        max_length=1000
    )


class JewelryBudgetInput(BaseModel):

    total_budget: float = Field(
        gt=0
    )

    occasion: str = Field(
        min_length=2,
        max_length=100
    )

    preferences: Optional[str] = Field(
        default=None,
        max_length=500
    )