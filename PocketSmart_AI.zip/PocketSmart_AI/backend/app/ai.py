from __future__ import annotations

import json
import os
import time
from dotenv import load_dotenv
load_dotenv(override=True)
from typing import Any, Optional

from google import genai
from google.genai import types


# ============================================================
# GEMINI CONFIGURATION
# ============================================================

GEMINI_MODEL = "gemini-3.5-flash-lite"


def get_gemini_client():
    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        return None

    try:
        return genai.Client(api_key=api_key)
    except Exception:
        return None


def ask_gemini(prompt: str) -> Optional[dict[str, Any]]:
    """
    Ask Gemini to return JSON.
    Retries temporary 503 errors before using local fallback.
    """
    client = get_gemini_client()

    if client is None:
        return None

    for attempt in range(3):
        try:
            response = client.models.generate_content(
                model=GEMINI_MODEL,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json"
                ),
            )

            text = response.text.strip()

            if not text:
                return None

            result = json.loads(text)

            if isinstance(result, dict):
                return result

            return None

        except Exception as error:
            error_text = str(error)

            print(
                f"Gemini attempt {attempt + 1}/3 failed: {error_text}"
            )

            if "503" in error_text or "UNAVAILABLE" in error_text:
                if attempt < 2:
                    time.sleep(2)
                    continue

            return None

    return None


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def money(value: float) -> float:
    return round(float(value), 2)


def text(value: Optional[str], default: str = "") -> str:
    if value is None:
        return default

    value = str(value).strip()

    return value if value else default


# ============================================================
# HOME INTERIOR
# ============================================================

def generate_home_recommendations(
    total_budget: float,
    room_type: str,
    style: Optional[str] = None,
    priorities: Optional[str] = None,
    additional_requirements: Optional[str] = None,
) -> dict[str, Any]:

    budget = float(total_budget)

    room = text(
        room_type,
        "Living Room"
    )

    selected_style = text(
        style,
        "Modern"
    )

    selected_priorities = text(
        priorities,
        "Comfort and appearance"
    )

    requirements = text(
        additional_requirements,
        "No additional requirements"
    )

    prompt = f"""
You are PocketSmart AI, an intelligent personal shopping assistant.

Create a practical home interior recommendation.

User details:

Total budget: ₹{budget}
Room type: {room}
Preferred style: {selected_style}
Priorities: {selected_priorities}
Additional requirements: {requirements}

Important rules:

1. Stay within the total budget.
2. Use realistic approximate Indian prices.
3. Give useful categories and individual products.
4. Do not exceed the total budget.
5. Return ONLY valid JSON.
6. Do not use markdown.
7. Keep the response concise but useful.

Return exactly this JSON structure:

{{
  "type": "home",
  "source": "gemini_ai",
  "total_budget": 0,
  "remaining_budget": 0,
  "room_type": "",
  "style": "",
  "priorities": "",
  "additional_requirements": "",
  "budget_breakdown": [
    {{
      "category": "",
      "allocation": 0,
      "items": [
        {{
          "name": "",
          "description": "",
          "quantity": 1,
          "estimated_price": 0,
          "search_terms": ""
        }}
      ]
    }}
  ],
  "additional_suggestions": []
}}
"""

    result = ask_gemini(prompt)

    if result:
        result["source"] = "gemini_ai"
        return result

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    furniture = budget * 0.30
    lighting = budget * 0.10
    storage = budget * 0.15
    decor = budget * 0.15
    textiles = budget * 0.10

    allocated = (
        furniture
        + lighting
        + storage
        + decor
        + textiles
    )

    remaining = budget - allocated

    return {
        "type": "home",
        "source": "local_fallback",
        "total_budget": money(budget),
        "remaining_budget": money(remaining),
        "room_type": room,
        "style": selected_style,
        "priorities": selected_priorities,
        "additional_requirements": requirements,

        "budget_breakdown": [
            {
                "category": "Furniture",
                "allocation": money(furniture),
                "items": [
                    {
                        "name": "Sofa",
                        "description": f"{selected_style} sofa for {room}",
                        "quantity": 1,
                        "estimated_price": money(furniture * 0.70),
                        "search_terms": f"{selected_style} sofa {room}",
                    },
                    {
                        "name": "Center Table",
                        "description": "Simple center table",
                        "quantity": 1,
                        "estimated_price": money(furniture * 0.30),
                        "search_terms": f"{selected_style} center table",
                    },
                ],
            },
            {
                "category": "Lighting",
                "allocation": money(lighting),
                "items": [
                    {
                        "name": "Ceiling Light",
                        "description": "Main room lighting",
                        "quantity": 1,
                        "estimated_price": money(lighting * 0.60),
                        "search_terms": f"{selected_style} ceiling light",
                    },
                    {
                        "name": "Table Lamp",
                        "description": "Decorative table lamp",
                        "quantity": 1,
                        "estimated_price": money(lighting * 0.40),
                        "search_terms": f"{selected_style} table lamp",
                    },
                ],
            },
            {
                "category": "Storage",
                "allocation": money(storage),
                "items": [
                    {
                        "name": "Storage Cabinet",
                        "description": "Useful storage cabinet",
                        "quantity": 1,
                        "estimated_price": money(storage * 0.65),
                        "search_terms": f"{selected_style} storage cabinet",
                    },
                    {
                        "name": "Wall Shelves",
                        "description": "Space-saving wall shelves",
                        "quantity": 1,
                        "estimated_price": money(storage * 0.35),
                        "search_terms": f"{selected_style} wall shelves",
                    },
                ],
            },
            {
                "category": "Decor",
                "allocation": money(decor),
                "items": [
                    {
                        "name": "Wall Art",
                        "description": "Decorative wall art",
                        "quantity": 2,
                        "estimated_price": money(decor * 0.45),
                        "search_terms": f"{selected_style} wall art",
                    },
                    {
                        "name": "Indoor Plants",
                        "description": "Indoor decorative plants",
                        "quantity": 2,
                        "estimated_price": money(decor * 0.30),
                        "search_terms": "indoor plants home decor",
                    },
                ],
            },
            {
                "category": "Textiles",
                "allocation": money(textiles),
                "items": [
                    {
                        "name": "Curtains",
                        "description": "Matching curtains",
                        "quantity": 1,
                        "estimated_price": money(textiles * 0.50),
                        "search_terms": f"{selected_style} curtains",
                    },
                    {
                        "name": "Cushion Set",
                        "description": "Decorative cushions",
                        "quantity": 1,
                        "estimated_price": money(textiles * 0.50),
                        "search_terms": f"{selected_style} cushion covers",
                    },
                ],
            },
        ],

        "additional_suggestions": [
            "Measure the room before purchasing furniture.",
            "Compare prices before buying.",
            "Keep some money for unexpected expenses.",
        ],
    }


# ============================================================
# PARTY PLANNER
# ============================================================

def generate_party_recommendations(
    total_budget: float,
    party_type: str,
    num_guests: int,
    venue_type: Optional[str] = None,
    event_date: Optional[str] = None,
    needs: Optional[str] = None,
    additional_requirements: Optional[str] = None,
) -> dict[str, Any]:

    budget = float(total_budget)
    guests = int(num_guests)

    party = text(
        party_type,
        "Birthday Party"
    )

    venue = text(
        venue_type,
        "Indoor Venue"
    )

    date = text(
        event_date,
        "Not specified"
    )

    party_needs = text(
        needs,
        "Food, decoration and entertainment"
    )

    requirements = text(
        additional_requirements,
        "No additional requirements"
    )

    prompt = f"""
You are PocketSmart AI, an intelligent event planning assistant.

Create a practical party plan.

Party type: {party}
Number of guests: {guests}
Total budget: ₹{budget}
Venue type: {venue}
Event date: {date}
Needs: {party_needs}
Additional requirements: {requirements}

Rules:

1. Stay within the total budget.
2. Use realistic approximate Indian prices.
3. Include venue, food, decoration, entertainment and gifts.
4. Give individual items inside every category.
5. Do not exceed the budget.
6. Return ONLY valid JSON.
7. Do not use markdown.

Return exactly this JSON structure:

{{
  "type": "party",
  "source": "gemini_ai",
  "total_budget": 0,
  "remaining_budget": 0,
  "party_type": "",
  "num_guests": 0,
  "venue_type": "",
  "event_date": "",
  "needs": "",
  "additional_requirements": "",
  "budget_breakdown": [
    {{
      "category": "",
      "allocation": 0,
      "items": [
        {{
          "name": "",
          "description": "",
          "quantity": 1,
          "estimated_price": 0,
          "search_terms": ""
        }}
      ]
    }}
  ],
  "additional_suggestions": []
}}
"""

    result = ask_gemini(prompt)

    if result:
        result["source"] = "gemini_ai"
        return result

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    venue_budget = budget * 0.20
    food_budget = budget * 0.35
    decoration_budget = budget * 0.15
    entertainment_budget = budget * 0.10
    gifts_budget = budget * 0.10

    allocated = (
        venue_budget
        + food_budget
        + decoration_budget
        + entertainment_budget
        + gifts_budget
    )

    remaining = budget - allocated

    return {
        "type": "party",
        "source": "local_fallback",
        "total_budget": money(budget),
        "remaining_budget": money(remaining),
        "party_type": party,
        "num_guests": guests,
        "venue_type": venue,
        "event_date": date,
        "needs": party_needs,
        "additional_requirements": requirements,

        "budget_breakdown": [
            {
                "category": "Venue",
                "allocation": money(venue_budget),
                "items": [
                    {
                        "name": "Venue Booking",
                        "description": f"{venue} for {guests} guests",
                        "quantity": 1,
                        "estimated_price": money(venue_budget),
                        "search_terms": f"{venue} party venue {party}",
                    }
                ],
            },
            {
                "category": "Food",
                "allocation": money(food_budget),
                "items": [
                    {
                        "name": "Main Food",
                        "description": f"Food for {guests} guests",
                        "quantity": guests,
                        "estimated_price": money(food_budget * 0.70),
                        "search_terms": f"{party} catering food",
                    },
                    {
                        "name": "Snacks and Beverages",
                        "description": "Snacks and beverages",
                        "quantity": guests,
                        "estimated_price": money(food_budget * 0.30),
                        "search_terms": f"{party} snacks beverages",
                    },
                ],
            },
            {
                "category": "Decoration",
                "allocation": money(decoration_budget),
                "items": [
                    {
                        "name": "Balloon Decoration",
                        "description": "Party balloon decoration",
                        "quantity": 1,
                        "estimated_price": money(decoration_budget * 0.45),
                        "search_terms": f"{party} balloon decoration",
                    },
                    {
                        "name": "Party Backdrop",
                        "description": "Main party backdrop",
                        "quantity": 1,
                        "estimated_price": money(decoration_budget * 0.35),
                        "search_terms": f"{party} party backdrop",
                    },
                ],
            },
            {
                "category": "Entertainment",
                "allocation": money(entertainment_budget),
                "items": [
                    {
                        "name": "Music Setup",
                        "description": "Speaker and music setup",
                        "quantity": 1,
                        "estimated_price": money(entertainment_budget * 0.60),
                        "search_terms": f"{party} party speaker",
                    },
                    {
                        "name": "Party Games",
                        "description": "Games for guests",
                        "quantity": 1,
                        "estimated_price": money(entertainment_budget * 0.40),
                        "search_terms": "party games",
                    },
                ],
            },
            {
                "category": "Gifts",
                "allocation": money(gifts_budget),
                "items": [
                    {
                        "name": "Return Gifts",
                        "description": f"Return gifts for {guests} guests",
                        "quantity": guests,
                        "estimated_price": money(gifts_budget),
                        "search_terms": f"{party} return gifts",
                    }
                ],
            },
        ],

        "additional_suggestions": [
            "Confirm the venue before booking.",
            "Compare catering prices.",
            "Confirm event timings.",
            "Keep some money for last-minute expenses.",
        ],
    }


# ============================================================
# JEWELRY PLANNER
# ============================================================

def generate_jewelry_recommendations(
    total_budget: float,
    occasion: str,
    preferences: Optional[str] = None,
    image_provided: bool = False,
) -> dict[str, Any]:

    budget = float(total_budget)

    selected_occasion = text(
        occasion,
        "General Occasion"
    )

    selected_preferences = text(
        preferences,
        "Elegant and simple"
    )

    prompt = f"""
You are PocketSmart AI, a jewelry recommendation assistant.

Create a jewelry shopping recommendation.

Total budget: ₹{budget}
Occasion: {selected_occasion}
Preferences: {selected_preferences}
Outfit image provided: {image_provided}

Rules:

1. Stay within the total budget.
2. Recommend suitable earrings, necklace and bracelet.
3. Use realistic approximate Indian prices.
4. Consider the occasion and preferences.
5. If no image is available, do not claim that you visually analyzed an outfit.
6. Return ONLY valid JSON.
7. Do not use markdown.

Return exactly:

{{
  "type": "jewelry",
  "source": "gemini_ai",
  "total_budget": 0,
  "remaining_budget": 0,
  "occasion": "",
  "preferences": "",
  "jewelry_recommendations": [
    {{
      "item_type": "",
      "description": "",
      "style": "",
      "estimated_price": 0,
      "search_terms": ""
    }}
  ],
  "outfit_analysis": {{
    "colors": [],
    "style": "",
    "formality": ""
  }},
  "image_note": "",
  "additional_suggestions": []
}}
"""

    result = ask_gemini(prompt)

    if result:
        result["source"] = "gemini_ai"
        return result

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    earrings = budget * 0.25
    necklace = budget * 0.35
    bracelet = budget * 0.20
    remaining = budget * 0.20

    occasion_lower = selected_occasion.lower()
    preferences_lower = selected_preferences.lower()

    if (
        "traditional" in preferences_lower
        or "traditional" in occasion_lower
    ):
        style = "Traditional"
    elif (
        "bridal" in preferences_lower
        or "wedding" in occasion_lower
    ):
        style = "Bridal"
    elif (
        "minimal" in preferences_lower
        or "simple" in preferences_lower
    ):
        style = "Minimal and Elegant"
    else:
        style = "Elegant Contemporary"

    return {
        "type": "jewelry",
        "source": "local_fallback",
        "total_budget": money(budget),
        "remaining_budget": money(remaining),
        "occasion": selected_occasion,
        "preferences": selected_preferences,

        "jewelry_recommendations": [
            {
                "item_type": "Earrings",
                "description": f"Earrings suitable for {selected_occasion}",
                "style": style,
                "estimated_price": money(earrings),
                "search_terms": f"{style} earrings {selected_occasion}",
            },
            {
                "item_type": "Necklace",
                "description": f"Necklace suitable for {selected_occasion}",
                "style": style,
                "estimated_price": money(necklace),
                "search_terms": f"{style} necklace {selected_occasion}",
            },
            {
                "item_type": "Bracelet",
                "description": "Matching bracelet",
                "style": style,
                "estimated_price": money(bracelet),
                "search_terms": f"{style} bracelet",
            },
        ],

        "outfit_analysis": {
            "colors": [
                "Neutral",
                "Complementary shades"
            ],
            "style": style,
            "formality": (
                "Formal"
                if (
                    "wedding" in occasion_lower
                    or "bridal" in occasion_lower
                )
                else "Semi-formal"
            ),
        },

        "image_note": (
            "An outfit image was provided, "
            "but image analysis is not enabled in fallback mode."
            if image_provided
            else "No outfit image was provided."
        ),

        "additional_suggestions": [
            "Match jewelry color with the outfit.",
            "Choose jewelry according to the occasion.",
            "Compare prices before purchasing.",
            "Keep some budget for price changes.",
        ],
    }


# ============================================================
# GENERAL FUNCTION
# ============================================================

def generate_recommendations(
    recommendation_type: str,
    data: dict[str, Any],
) -> dict[str, Any]:

    recommendation_type = recommendation_type.strip().lower()

    if recommendation_type == "home":
        return generate_home_recommendations(
            total_budget=data["total_budget"],
            room_type=data["room_type"],
            style=data.get("style"),
            priorities=data.get("priorities"),
            additional_requirements=data.get(
                "additional_requirements"
            ),
        )

    if recommendation_type == "party":
        return generate_party_recommendations(
            total_budget=data["total_budget"],
            party_type=data["party_type"],
            num_guests=data["num_guests"],
            venue_type=data.get("venue_type"),
            event_date=data.get("event_date"),
            needs=data.get("needs"),
            additional_requirements=data.get(
                "additional_requirements"
            ),
        )

    if recommendation_type == "jewelry":
        return generate_jewelry_recommendations(
            total_budget=data["total_budget"],
            occasion=data["occasion"],
            preferences=data.get("preferences"),
            image_provided=data.get(
                "image_provided",
                False
            ),
        )

    raise ValueError(
        f"Unsupported recommendation type: {recommendation_type}"
    )