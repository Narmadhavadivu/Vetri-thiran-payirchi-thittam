from __future__ import annotations

from urllib.parse import quote_plus


# ============================================================
# SHOPPING PLATFORMS
# ============================================================

PLATFORMS = {
    "amazon": lambda q:
        f"https://www.amazon.in/s?k={q}",

    "flipkart": lambda q:
        f"https://www.flipkart.com/search?q={q}",

    "ikea": lambda q:
        f"https://www.ikea.com/in/en/search/?q={q}",

    "myntra": lambda q:
        f"https://www.myntra.com/search?q={q}",

    "ajio": lambda q:
        f"https://www.ajio.com/search/?text={q}",

    "meesho": lambda q:
        f"https://www.meesho.com/search?q={q}",

    "bigbasket": lambda q:
        f"https://www.bigbasket.com/ps/?q={q}",

    "swiggy": lambda q:
        f"https://www.swiggy.com/search?query={q}",

    "zomato": lambda q:
        f"https://www.zomato.com/search?q={q}",

    "bookmyshow": lambda q:
        f"https://in.bookmyshow.com/explore/search?query={q}",

    "google": lambda q:
        f"https://www.google.com/search?q={q}",

    "booking": lambda q:
        f"https://www.booking.com/search.html?ss={q}",

    "makemytrip": lambda q:
        f"https://www.makemytrip.com/hotels/hotel-listing/?searchText={q}",

    "oyorooms": lambda q:
        f"https://www.oyorooms.com/search/?location={q}",

    "nobroker": lambda q:
        f"https://www.nobroker.in/property/search?searchTerm={q}",

    "tanishq": lambda q:
        f"https://www.tanishq.co.in/search?q={q}",

    "caratlane": lambda q:
        f"https://www.caratlane.com/search?q={q}",

    "bluestone": lambda q:
        f"https://www.bluestone.com/search.html?query={q}",

    "melorra": lambda q:
        f"https://www.melorra.com/search?q={q}",
}


# ============================================================
# CREATE SHOPPING LINKS
# ============================================================

def make_links(
    search_terms: str,
    platforms: list[str],
) -> dict[str, str]:

    query = quote_plus(
        str(search_terms).strip()
    )

    links = {}

    for platform in platforms:

        if platform in PLATFORMS:
            links[platform] = PLATFORMS[platform](query)

    return links


# ============================================================
# HOME INTERIOR LINKS
# ============================================================

def add_home_links(
    result: dict,
) -> dict:

    categories = result.get(
        "budget_breakdown",
        [],
    )

    for category in categories:

        items = category.get(
            "items",
            [],
        )

        for item in items:

            search_terms = item.get(
                "search_terms",
                "",
            )

            if search_terms:

                item["shopping_links"] = make_links(
                    search_terms,
                    [
                        "amazon",
                        "flipkart",
                        "ikea",
                        "myntra",
                        "ajio",
                    ],
                )

    return result


# ============================================================
# PARTY PLANNER PLATFORMS
# ============================================================

PARTY_PLATFORMS = {
    "venue": [
        "google",
        "booking",
        "makemytrip",
        "oyorooms",
        "nobroker",
    ],

    "food": [
        "swiggy",
        "zomato",
    ],

    "decoration": [
        "amazon",
        "flipkart",
        "meesho",
        "myntra",
    ],

    "entertainment": [
        "bookmyshow",
        "amazon",
        "flipkart",
    ],

    "gifts": [
        "amazon",
        "flipkart",
        "myntra",
        "meesho",
    ],
}


# ============================================================
# PARTY LINKS
# ============================================================

def add_party_links(
    result: dict,
) -> dict:

    categories = result.get(
        "budget_breakdown",
        [],
    )

    for category in categories:

        category_name = str(
            category.get(
                "category",
                "",
            )
        ).lower()

        platforms = PARTY_PLATFORMS.get(
            category_name,
            [
                "amazon",
                "flipkart",
                "google",
            ],
        )

        items = category.get(
            "items",
            [],
        )

        for item in items:

            search_terms = item.get(
                "search_terms",
                "",
            )

            if search_terms:

                item["shopping_links"] = make_links(
                    search_terms,
                    platforms,
                )

    return result


# ============================================================
# JEWELRY LINKS
# ============================================================

def add_jewelry_links(
    result: dict,
) -> dict:

    recommendations = result.get(
        "jewelry_recommendations",
        [],
    )

    for item in recommendations:

        search_terms = item.get(
            "search_terms",
            "",
        )

        if search_terms:

            item["shopping_links"] = make_links(
                search_terms,
                [
                    "amazon",
                    "flipkart",
                    "tanishq",
                    "caratlane",
                    "bluestone",
                    "melorra",
                    "meesho",
                ],
            )

    return result