from __future__ import annotations

import json
from typing import Optional

from fastapi import (
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    UploadFile,
)
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session

from .ai import (
    generate_home_recommendations,
    generate_party_recommendations,
    generate_jewelry_recommendations,
)
from .auth import (
    authenticate_user,
    create_access_token,
    get_current_user,
    hash_password,
)
from .database import (
    RecommendationHistory,
    User,
    get_db,
    init_db,
)
from .shopping import (
    add_home_links,
    add_party_links,
    add_jewelry_links,
)


# ============================================================
# FASTAPI APPLICATION
# ============================================================

app = FastAPI(
    title="PocketSmart AI",
    description="AI-powered personal shopping assistant",
    version="1.0.0",
)


# ============================================================
# DATABASE STARTUP
# ============================================================

@app.on_event("startup")
def startup():
    init_db()


# ============================================================
# CORS
# ============================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# REQUEST MODELS
# ============================================================

class RegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    username: str
    password: str


# ============================================================
# BASIC ROUTES
# ============================================================

@app.get("/")
def root():
    return {
        "message": "PocketSmart AI Backend is running!",
        "status": "success",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
    }


# ============================================================
# AUTH - REGISTER
# ============================================================

@app.post("/auth/register")
def register(
    data: RegisterRequest,
    db: Session = Depends(get_db),
):
    username = data.username.strip()
    email = str(data.email).strip().lower()

    if not username:
        raise HTTPException(
            status_code=400,
            detail="Username is required",
        )

    # Check username
    existing_user = (
        db.query(User)
        .filter(User.username == username)
        .first()
    )

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Username already exists",
        )

    # Check email
    existing_email = (
        db.query(User)
        .filter(User.email == email)
        .first()
    )

    if existing_email:
        raise HTTPException(
            status_code=400,
            detail="Email already exists",
        )

    # Create user
    user = User(
        username=username,
        email=email,
        password_hash=hash_password(data.password),
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    return {
        "message": "Account created successfully",
        "username": user.username,
    }


# ============================================================
# AUTH - LOGIN
# ============================================================

@app.post("/auth/login")
def login(
    data: LoginRequest,
    db: Session = Depends(get_db),
):
    username = data.username.strip()

    user = authenticate_user(
        db,
        username,
        data.password,
    )

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid username or password",
        )

    token = create_access_token(
        user.username,
    )

    return {
        "access_token": token,
        "token_type": "bearer",
    }


# ============================================================
# AUTH - CURRENT USER
# ============================================================

@app.get("/auth/me")
def get_me(
    current_user: User = Depends(get_current_user),
):
    return {
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
    }


# ============================================================
# HELPER - SAVE RECOMMENDATION HISTORY
# ============================================================

def save_history(
    db: Session,
    current_user: User,
    recommendation_type: str,
    input_data: dict,
    result: dict,
):
    history = RecommendationHistory(
        user_id=current_user.id,
        recommendation_type=recommendation_type,
        input_summary=json.dumps(
            input_data,
            ensure_ascii=False,
        ),
        result_json=json.dumps(
            result,
            ensure_ascii=False,
        ),
        total_budget=float(
            result.get("total_budget", 0)
        ),
    )

    db.add(history)
    db.commit()
    db.refresh(history)

    return history


# ============================================================
# HOME INTERIOR PLANNER
# ============================================================

@app.post("/api/home-budget")
def home_budget(
    data: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Home Interior recommendation endpoint.

    Expected data:
    {
        "total_budget": number,
        "room_type": string,
        "style": string,
        "priorities": string,
        "additional_requirements": string
    }
    """

    try:
        total_budget = float(
            data.get("total_budget", 0)
        )
    except (TypeError, ValueError):
        total_budget = 0

    if total_budget <= 0:
        raise HTTPException(
            status_code=422,
            detail="Total budget must be greater than 0",
        )

    room_type = str(
        data.get(
            "room_type",
            "Living Room",
        )
    ).strip()

    if not room_type:
        raise HTTPException(
            status_code=422,
            detail="Room type is required",
        )

    style = data.get("style")
    priorities = data.get("priorities")
    additional_requirements = data.get(
        "additional_requirements"
    )

    try:
        result = generate_home_recommendations(
            total_budget=total_budget,
            room_type=room_type,
            style=style,
            priorities=priorities,
            additional_requirements=additional_requirements,
        )

        # Add shopping links
        result = add_home_links(result)

        # Save history
        save_history(
            db=db,
            current_user=current_user,
            recommendation_type="home",
            input_data={
                "total_budget": total_budget,
                "room_type": room_type,
                "style": style,
                "priorities": priorities,
                "additional_requirements":
                    additional_requirements,
            },
            result=result,
        )

        return result

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Home recommendation failed: {error}",
        )


# ============================================================
# PARTY PLANNER
# ============================================================

@app.post("/api/party-budget")
def party_budget(
    data: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Party Planner recommendation endpoint.

    Expected data:
    {
        "total_budget": number,
        "party_type": string,
        "num_guests": number,
        "venue_type": string,
        "event_date": string,
        "needs": string,
        "additional_requirements": string
    }
    """

    try:
        total_budget = float(
            data.get("total_budget", 0)
        )
    except (TypeError, ValueError):
        total_budget = 0

    if total_budget <= 0:
        raise HTTPException(
            status_code=422,
            detail="Total budget must be greater than 0",
        )

    party_type = str(
        data.get(
            "party_type",
            "Birthday Party",
        )
    ).strip()

    if not party_type:
        raise HTTPException(
            status_code=422,
            detail="Party type is required",
        )

    try:
        num_guests = int(
            data.get("num_guests", 0)
        )
    except (TypeError, ValueError):
        num_guests = 0

    if num_guests <= 0:
        raise HTTPException(
            status_code=422,
            detail="Number of guests must be greater than 0",
        )

    venue_type = data.get("venue_type")
    event_date = data.get("event_date")
    needs = data.get("needs")
    additional_requirements = data.get(
        "additional_requirements"
    )

    try:
        result = generate_party_recommendations(
            total_budget=total_budget,
            party_type=party_type,
            num_guests=num_guests,
            venue_type=venue_type,
            event_date=event_date,
            needs=needs,
            additional_requirements=additional_requirements,
        )

        # Add shopping/service links
        result = add_party_links(result)

        # Save history
        save_history(
            db=db,
            current_user=current_user,
            recommendation_type="party",
            input_data={
                "total_budget": total_budget,
                "party_type": party_type,
                "num_guests": num_guests,
                "venue_type": venue_type,
                "event_date": event_date,
                "needs": needs,
                "additional_requirements":
                    additional_requirements,
            },
            result=result,
        )

        return result

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Party recommendation failed: {error}",
        )


# ============================================================
# JEWELRY PLANNER
# ============================================================

@app.post("/api/jewelry-budget")
async def jewelry_budget(
    total_budget: float = Form(...),
    occasion: str = Form(...),
    preferences: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Jewelry Planner recommendation endpoint.

    Accepts multipart/form-data because the frontend
    can optionally upload an outfit image.
    """

    if total_budget <= 0:
        raise HTTPException(
            status_code=422,
            detail="Total budget must be greater than 0",
        )

    occasion = occasion.strip()

    if not occasion:
        raise HTTPException(
            status_code=422,
            detail="Occasion is required",
        )

    image_provided = image is not None

    try:
        result = generate_jewelry_recommendations(
            total_budget=total_budget,
            occasion=occasion,
            preferences=preferences,
            image_provided=image_provided,
        )

        # Add jewelry shopping links
        result = add_jewelry_links(result)

        # Save history
        save_history(
            db=db,
            current_user=current_user,
            recommendation_type="jewelry",
            input_data={
                "total_budget": total_budget,
                "occasion": occasion,
                "preferences": preferences,
                "image_provided": image_provided,
                "image_filename": (
                    image.filename
                    if image
                    else None
                ),
            },
            result=result,
        )

        return result

    except Exception as error:
        raise HTTPException(
    status_code=404,
    detail="Recommendation history not found",
)


# ============================================================
# RECOMMENDATION HISTORY
# ============================================================

@app.get("/api/history")
def get_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Return recommendation history for the logged-in user.
    """

    records = (
        db.query(RecommendationHistory)
        .filter(
            RecommendationHistory.user_id
            == current_user.id
        )
        .order_by(
            RecommendationHistory.created_at.desc()
        )
        .all()
    )

    history = []

    for record in records:

        try:
            result = json.loads(
                record.result_json
            )
        except (json.JSONDecodeError, TypeError):
            result = {}

        history.append(
            {
                "id": record.id,
                "type": record.recommendation_type,
                "total_budget": record.total_budget,
                "timestamp": (
                    record.created_at.isoformat()
                    if record.created_at
                    else None
                ),
                "summary": {
                    "source": result.get(
                        "source",
                        "Gemini AI",
                    ),
                    "remaining_budget": result.get(
                        "remaining_budget",
                        0,
                    ),
                },
            }
        )

    return history


# ============================================================
# SINGLE HISTORY RECORD
# ============================================================

@app.get("/api/history/{history_id}")
def get_history_item(
    history_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Return one recommendation from history.
    """

    record = (
        db.query(RecommendationHistory)
        .filter(
            RecommendationHistory.id
            == history_id,
            RecommendationHistory.user_id
            == current_user.id,
        )
        .first()
    )

    if not record:
        raise HTTPException(
            status_code=404,
            detail="Recommendation history not found",
        )

    try:
        result = json.loads(
            record.result_json
        )
    except (json.JSONDecodeError, TypeError):
        result = {}

    return {
        "id": record.id,
        "type": record.recommendation_type,
        "total_budget": record.total_budget,
        "timestamp": (
            record.created_at.isoformat()
            if record.created_at
            else None
        ),
        "result": result,
    }


# ============================================================
# DELETE HISTORY RECORD
# ============================================================

@app.delete("/api/history/{history_id}")
def delete_history_item(
    history_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Delete one recommendation history record.
    """

    record = (
        db.query(RecommendationHistory)
        .filter(
            RecommendationHistory.id
            == history_id,
            RecommendationHistory.user_id
            == current_user.id,
        )
        .first()
    )

    if not record:
        raise HTTPException(
            status_code=404,
            detail="Recommendation history not found",
        )

    db.delete(record)
    db.commit()

    return {
        "message": "History deleted successfully",
        "id": history_id,
    }